//
//  weatherAppApp.swift
//  weatherApp
//
//  Created by shreyas on 13/12/22.
//

import SwiftUI

@main
struct weatherAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
