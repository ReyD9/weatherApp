//
//  WeatherView.swift
//  weatherApp
//
//  Created by shreyas on 17/12/22.
//

import SwiftUI

struct WeatherView: View {
    @State private var searchText = ""
    
    var searchResults:[Forecast]{
        if searchText.isEmpty{
            return Forecast.cities
        }else{
            return Forecast.cities.filter{ $0.location.contains(searchText)}
        }
    }
    var body: some View {
        ZStack{
            Color.background
                .ignoresSafeArea()
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 20) {
                    ForEach(searchResults){ forecast in WeatherWidgets(forecast: forecast)
                        
                    }
                }
            }
            .safeAreaInset(edge: .top) {
                EmptyView()
                    .frame(height: 100)
            }
        }
        .overlay{
            NavigationBar(searchText: $searchText)
        }
       .navigationBarHidden(true)
//        .searchable(text: $searchTeaxt, placement: .navigationBarDrawer(displayMode: .always), prompt: "Any Specific OR Just Browsing")
    }
}

struct WeatherView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            WeatherView()
                .preferredColorScheme(.dark)
        }
    }
}
