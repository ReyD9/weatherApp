//
//  TabBar.swift
//  weatherApp
//
//  Created by shreyas on 13/12/22.
//

import SwiftUI

struct TabBar: View {
    //adding action
    var action: () -> Void       // () -> void = function returning void
    var body: some View {
        ZStack{
            
            //arc shape
            Arc()
                .fill(Color.tabBarBackground)
                .frame(height: 88)
                .overlay {
                    Arc()
                        .stroke(Color.tabBarBackground, lineWidth: 0.5)
                }
            
            HStack{
                //expanding button
                Button{
                    action()
                }label: {
                    Image(systemName: "mappin.and.ellipse")  //from the sf symbol app
                        .frame(width: 50, height: 50)
                }
                
                Spacer()
                
                
                //navigation button
                NavigationLink {
                    WeatherView()
                } label: {
                    Image(systemName: "list.star")
                        .frame(width: 50, height: 50)
                }

            }
            .font(.title3)
            .foregroundColor(.white)
            .padding(EdgeInsets(top: 20, leading: 32, bottom: 24, trailing: 32))
        }
        .frame(maxHeight: .infinity, alignment: .bottom)
        .ignoresSafeArea()
    }
}

struct TabBar_Previews: PreviewProvider {
    static var previews: some View {
        TabBar(action: {})       // {} no action
            .preferredColorScheme(.dark)
    }
}
